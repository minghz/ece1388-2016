* # File name: /nfs/ug/homes-1/z/zhaomin4/ece1388-2016/cmosp35/simulation/
# tb_inverter/hspiceS/schematic/netlist/tb_inverter.c.raw
# Netlist output for hspiceS.
# Generated on Sep 25 16:20:15 2016

# global net definitions
.GLOBAL vdd!
USE TestLib_tb_inverter_schematic

USE TestLib_inverter_schematic inverter_g1

USEM nch nch
USEM pch pch

# Include files



# End of Netlist
