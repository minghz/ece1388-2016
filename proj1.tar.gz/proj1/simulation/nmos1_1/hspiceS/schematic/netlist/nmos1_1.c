* # File name: /nfs/ug/homes-1/z/zhaomin4/ece1388-2016/proj1/simulation/
# nmos1_1/hspiceS/schematic/netlist/nmos1_1.c.raw
# Netlist output for hspiceS.
# Generated on Oct 4 18:27:13 2016

USE proj1_nmos1_1_schematic


USEM nch nch

# Include files



# End of Netlist
