* # File name: /nfs/ug/homes-1/z/zhaomin4/ece1388-2016/proj1/simulation/
# eff_gate_cap_2_1/hspiceS/schematic/netlist/eff_gate_cap_2_1.c.raw
# Netlist output for hspiceS.
# Generated on Oct 1 14:43:04 2016

USE proj1_eff_gate_cap_2_1_schematic


USEM nch nch
USEM pch pch

# Include files



# End of Netlist
