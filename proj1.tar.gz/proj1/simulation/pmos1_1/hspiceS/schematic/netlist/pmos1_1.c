* # File name: /nfs/ug/homes-1/z/zhaomin4/ece1388-2016/proj1/simulation/
# pmos1_1/hspiceS/schematic/netlist/pmos1_1.c.raw
# Netlist output for hspiceS.
# Generated on Oct 4 18:11:52 2016

# global net definitions
.GLOBAL vdd!
USE proj1_pmos1_1_schematic


USEM pch pch

# Include files



# End of Netlist
