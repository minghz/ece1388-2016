* # File name: /nfs/ug/homes-1/z/zhaomin4/ece1388-2016/proj1/simulation/
# eff_res_2_2/hspiceS/schematic/netlist/eff_res_2_2.c.raw
# Netlist output for hspiceS.
# Generated on Oct 5 22:36:42 2016

USE proj1_eff_res_2_2_schematic


USEM nch nch
USEM pch pch

# Include files



# End of Netlist
