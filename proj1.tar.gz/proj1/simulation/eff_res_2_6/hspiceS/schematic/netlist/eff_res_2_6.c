* # File name: /nfs/ug/homes-1/z/zhaomin4/ece1388-2016/proj1/simulation/
# eff_res_2_6/hspiceS/schematic/netlist/eff_res_2_6.c.raw
# Netlist output for hspiceS.
# Generated on Oct 5 23:39:29 2016

USE proj1_eff_res_2_6_schematic


USEM nch nch
USEM pch pch

# Include files



# End of Netlist
