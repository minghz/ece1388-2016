* # File name: /nfs/ug/homes-1/z/zhaomin4/ece1388-2016/proj1/simulation/
# inverter_c_test/hspiceS/schematic/netlist/inverter_c_test.c.raw
# Netlist output for hspiceS.
# Generated on Oct 3 20:10:50 2016

USE proj1_inverter_c_test_schematic

USE proj1_inverter_c_schematic inverter_c_g1

USEM nch nch
USEM pch pch

# Include files



# End of Netlist
