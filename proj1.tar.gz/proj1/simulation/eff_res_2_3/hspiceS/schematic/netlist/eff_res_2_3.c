* # File name: /nfs/ug/homes-1/z/zhaomin4/ece1388-2016/proj1/simulation/
# eff_res_2_3/hspiceS/schematic/netlist/eff_res_2_3.c.raw
# Netlist output for hspiceS.
# Generated on Oct 1 15:01:33 2016

USE proj1_eff_res_2_3_schematic


USEM nch nch
USEM pch pch

# Include files



# End of Netlist
