* # File name: /nfs/ug/homes-1/z/zhaomin4/ece1388-2016/proj2/simulation/
# decoder_test_flipall/hspiceS/schematic/netlist/decoder_test_flipall.c.raw
# Netlist output for hspiceS.
# Generated on Oct 22 17:09:06 2016

# global net definitions
.GLOBAL vdd!
USE proj2_decoder_test_flipall_schematic

USE proj2_decoder_sub_t_schematic decoder_sub_t_g2
USE proj2_decoder_schematic decoder_g3
USE proj2_decoder_sub_r_schematic decoder_sub_r_g1

USEM nch nch
USEM pch pch

# Include files






# End of Netlist
