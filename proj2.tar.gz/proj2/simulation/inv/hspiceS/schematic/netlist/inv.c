* # File name: /nfs/ug/homes-1/z/zhaomin4/ece1388-2016/proj2/simulation/inv/
# hspiceS/schematic/netlist/inv.c.raw
# Netlist output for hspiceS.
# Generated on Oct 21 00:01:30 2016

# global net definitions
.GLOBAL vdd!
USE proj2_inv_schematic


USEM nch nch
USEM pch pch

# Include files



# End of Netlist
