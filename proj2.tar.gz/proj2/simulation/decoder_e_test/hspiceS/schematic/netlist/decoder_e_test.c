* # File name: /nfs/ug/homes-1/z/zhaomin4/ece1388-2016/proj2/simulation/
# decoder_e_test/hspiceS/schematic/netlist/decoder_e_test.c.raw
# Netlist output for hspiceS.
# Generated on Oct 27 20:52:53 2016

# global net definitions
.GLOBAL vdd!
USE proj2_decoder_e_test_schematic

USE proj2_decoder_e_extracted decoder_e_g1

USEM nch nch
USEM pch pch

# Include files



# End of Netlist
