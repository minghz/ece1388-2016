* # File name: /nfs/ug/homes-1/z/zhaomin4/ece1388-2016/proj2/simulation/
# decoder_test_power_static_extracted/hspiceS/schematic/netlist/
# decoder_test_power_static_extracted.c.raw
# Netlist output for hspiceS.
# Generated on Oct 27 18:32:34 2016

# global net definitions
.GLOBAL vdd!
USE proj2_decoder_test_power_static_extracted_schematic

USE proj2_decoder_extracted decoder_g1

USEM nch nch
USEM pch pch

# Include files



# End of Netlist
