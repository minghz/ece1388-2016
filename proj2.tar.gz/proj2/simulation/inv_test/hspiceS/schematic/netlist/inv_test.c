* # File name: /nfs/ug/homes-1/z/zhaomin4/ece1388-2016/proj2/simulation/
# inv_test/hspiceS/schematic/netlist/inv_test.c.raw
# Netlist output for hspiceS.
# Generated on Oct 22 14:30:33 2016

# global net definitions
.GLOBAL vdd!
USE proj2_inv_test_schematic


USEM nch nch
USEM pch pch

# Include files



# End of Netlist
